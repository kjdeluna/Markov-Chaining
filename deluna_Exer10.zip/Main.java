public class Main{
    private final static String INPUT_FILENAME = "hmm.in";
    public static void main(String[] args){
        Markov mar = new Markov(INPUT_FILENAME);
    }
}